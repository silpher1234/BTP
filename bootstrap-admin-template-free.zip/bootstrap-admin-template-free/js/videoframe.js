
const exerciseVideo = document.getElementById('exercise-video');
const referenceVideo = document.getElementById('reference-video');
const exerciseSelect = document.getElementById('exercise-select');

exerciseSelect.addEventListener('change', function () {
    const selectedExercise = exerciseSelect.value;

    exerciseVideo.src = getExerciseVideoSource(selectedExercise);

    referenceVideo.src = getReferenceVideoSource(selectedExercise);
});


function getExerciseVideoSource(exercise) {
    const exerciseSources = {
        exercise1: 'exercise1-video.mp4',
        exercise2: 'exercise2-video.mp4',
    };
    return exerciseSources[exercise] || '';
}


function getReferenceVideoSource(exercise) {
    const referenceSources = {
        exercise1: 'exercise1-reference.mp4',
        exercise2: 'exercise2-reference.mp4',           
    };
    return referenceSources[exercise] || '';
}
