// Install necessary packages using npm install express mongoose body-parser

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Connect to MongoDB (replace 'your_database_url' with your actual MongoDB URL)
mongoose.connect('your_database_url', { useNewUrlParser: true, useUnifiedTopology: true });

// Create a schema for your form data
const formDataSchema = new mongoose.Schema({
  name: String,
  email: String,
  age: Number,
  gender: String,
  

  // Add more fields as needed
});

const FormData = mongoose.model('FormData', formDataSchema);

// Body parser middleware to parse form data
app.use(bodyParser.urlencoded({ extended: true }));

// Route for handling form submissions
app.post('/submit-form', (req, res) => {
  // Create a new FormData instance with the submitted data
  const formData = new FormData({
    name: req.body.name,
    email: req.body.email,
    age: req.body.age,
    gender: req.body.gender,
    // Map other form fields
  });

  // Save the form data to MongoDB
  formData.save((err) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error saving form data');
    } else {
      res.send('Form data saved successfully');
    }
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
