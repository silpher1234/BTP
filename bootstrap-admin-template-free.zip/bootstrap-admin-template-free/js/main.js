(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Sidebar Toggler
    $('.sidebar-toggler').click(function () {
        $('.sidebar, .content').toggleClass("open");
        return false;
    });


    // Progress Bar
    $('.pg-bar').waypoint(function () {
        $('.progress .progress-bar').each(function () {
            $(this).css("width", $(this).attr("aria-valuenow") + '%');
        });
    }, {offset: '80%'});


    // Calender
    // $('#calender').datetimepicker({
    //     inline: true,
    //     format: 'L'
    // });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        items: 1,
        dots: true,
        loop: true,
        nav : false
    });


    // Worldwide Sales Chart
    var ctx1 = $("#worldwide-sales").get(0).getContext("2d");
    var myChart1 = new Chart(ctx1, {
        type: "bar",
        data: {
            labels: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            datasets: [{
                    label: "Cardio",
                    data: [15, 10, 7, 7, 12, 10, 8],
                    backgroundColor: "rgba(0, 156, 255, .5)"
                },
                {
                    label: "Stretch",
                    data: [10, 13, 10, 9, 13, 12, 9],
                    backgroundColor: "#fff3cd"
                },
                {
                    label: "Body",
                    data: [12, 15, 13, 11, 7, 5, 12],
                    backgroundColor: "#f8d7da"
                }
            ]
            },
        options: {
            responsive: true
        }
    });


    // Salse & Revenue Chart
    var ctx2 = $("#salse-revenue").get(0).getContext("2d");
    var myChart2 = new Chart(ctx2, {
        type: "line",
        data: {
            labels: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
            datasets: [{
                label: "Stretch",
                data: [193, 180, 196, 175, 192, 178, 195],
                backgroundColor: "#fff3cd",
                fill: true
            },
                {
                    label: "Body",
                    data: [288, 279, 338, 305, 343, 357, 340],
                    backgroundColor: "#f8d7da",
                    fill: true
                },
                {
                    label: "Cardio",
                    data: [430, 372, 428, 380, 373, 404, 370],
                    backgroundColor: "rgba(0, 156, 255, .5)",
                    fill: true
                }
                
            ]
            },
        options: {
            responsive: true
        }
    });
    


    // Single Line Chart
    var ctx3 = $("#line-chart").get(0).getContext("2d");
    var myChart3 = new Chart(ctx3, {
        type: "line",
        data: {
            labels: ['','Single Leg Raise', 'Knee Pull', 'Crunches', 'Bicylce Crunches', 'Plank'],
            datasets: [{
                label: "Error Count",
                fill: false,
                backgroundColor: "#f8d7da",
                data: [0, 7, 8, 6, 9, 12]
            }]
        },
        options: {
            responsive: true
        }
    });


    // Single Bar Chart
    $('#calender').datetimepicker({
        inline: true,
        format: 'L',
    });
    
    
    

    

    // var ctx4 = $("#bar-chart").get(0).getContext("2d");
    // var myChart4 = new Chart(ctx4, {
    //     type: "bar",
    //     data: {
    //         labels: ["Italy", "France", "Spain", "USA", "Argentina"],
    //         datasets: [{
    //             backgroundColor: [
    //                 "rgba(0, 156, 255, .7)",
    //                 "rgba(0, 156, 255, .6)",
    //                 "rgba(0, 156, 255, .5)",
    //                 "rgba(0, 156, 255, .4)",
    //                 "rgba(0, 156, 255, .3)"
    //             ],
    //             data: [55, 49, 44, 24, 15]
    //         }]
    //     },
    //     options: {
    //         responsive: true
    //     }
    // });


    // Pie Chart
    var ctx5 = $("#pie-chart").get(0).getContext("2d");
    var myChart5 = new Chart(ctx5, {
        type: "pie",
        data: {
            labels: ["Cardio", "Stretch", "Body"],
            datasets: [{
                backgroundColor: [
                    "rgba(0, 156, 255, .7)",
                    "#fff3cd",
                    "#f8d7da"
                ],
                data: [428, 196, 338]
            }]
        },
        options: {
            responsive: true
        }
    });


    // Doughnut Chart
    // var ctx6 = $("#doughnut-chart").get(0).getContext("2d");
    // var myChart6 = new Chart(ctx6, {
    //     type: "doughnut",
    //     data: {
    //         labels: ["Consumed","Required"],
    //         datasets: [{
    //             backgroundColor: [
    //                 "rgba(0, 156, 255, .6)",
    //                 "White",
    //             ],
    //             data: [1.8,2.6]
    //         }]
    //     },
    //     options: {
    //         responsive: true
    //     }
    // });
    var ctx6 = $("#doughnut-chart").get(0).getContext("2d");

var myChart6 = new Chart(ctx6, {
    type: "doughnut",
    data: {
        labels: ["Consumed", "Required"],
        datasets: [{
            backgroundColor: [
                "rgba(0, 156, 255, .6)",
                "White",
            ],
            data: [1.8, 2.6]
        }]
    },
    options: {
        responsive: true,
        cutout: '60%', // Adjust the cutout percentage as needed
        plugins: {
            legend: {
                display: false
            }
        },
        animation: {
            onComplete: function (animation) {
                var chartInstance = animation.chart;
                var ctx = chartInstance.ctx;
                var width = chartInstance.width;
                var height = chartInstance.height;

                ctx.font = '30px Arial';
                ctx.fillStyle = 'black';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';

                var text = 'Age: 21';
                ctx.fillText(text, width / 2, height / 2);
            }
        }
    }
});



    

    
})(jQuery);

